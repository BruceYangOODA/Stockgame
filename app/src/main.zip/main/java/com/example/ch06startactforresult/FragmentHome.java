package com.example.ch06startactforresult;

import android.database.Cursor;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.HighLowDataEntry;
import com.anychart.charts.Stock;
import com.anychart.core.stock.Plot;
import com.anychart.data.Table;
import com.anychart.data.TableMapping;
import com.anychart.enums.StockSeriesType;

import java.util.ArrayList;
import java.util.List;

public class FragmentHome extends Fragment {

    private View myView;
    private Cursor cursor;
    private static int offset = -20;
    private static int number = 20;


    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //if(myView==null) {
            myView = inflater.inflate(R.layout.fragment_home, container, false);
            AnyChartView anyChartView = myView.findViewById(R.id.any_chart_view);
            anyChartView.setProgressBar(myView.findViewById(R.id.progress_bar));

            Table table = Table.instantiate("x");
            table.addData(getData());

            TableMapping mapping = table.mapAs("{open: 'open', high: 'high', low: 'low', close: 'close'}");

            Stock stock = AnyChart.stock();

            Plot plot = stock.plot(0);
            plot.yGrid(true)
                    .xGrid(true)
                    .yMinorGrid(true)
                    .xMinorGrid(true);

            plot.ema(table.mapAs("{value: 'close'}"), 20d, StockSeriesType.LINE);

            plot.ohlc(mapping)
                    .name("CSCO")
                    .legendItem("{\n" +
                            "        iconType: 'rising-falling'\n" +
                            "      }");

            stock.scroller().ohlc(mapping);

            anyChartView.setChart(stock);
    //    }
       
        return myView;//super.onCreateView(inflater, container, savedInstanceState);
    }

    private StockGameActivity getStockGameActivity(){
        return (StockGameActivity)getActivity();
    }
    
    private List<DataEntry> getData() {
        List<DataEntry> data = new ArrayList<>();

        double open,high,low,close;
        Long temp;
        cursor = null;
        cursor = getStockGameActivity().dbHelper.queryAllStockData();
        String today = getStockGameActivity().getCurrentDate();
        int index=0;
        if(cursor.getCount()>0)
        {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()){
                if(cursor.getString(0).equals(today))
                {
                    index = cursor.getPosition();

                    break;
                }
                cursor.moveToNext();
            }
        }
        for(int i=0;i<number;i++){
            cursor.moveToPosition(index+offset+i);
            open = cursor.getDouble(1);
            high = cursor.getDouble(2);
            low = cursor.getDouble(3);
            close = cursor.getDouble(4);
            temp = (1536044800000L+90000000*i);
            data.add(new OHCLDataEntry(temp,open,high,low,close));

        }

        return data;
    }

    private class OHCLDataEntry extends HighLowDataEntry {
        OHCLDataEntry(Long x, Double open, Double high, Double low, Double close) {
            super(x, high, low);
            setValue("open", open);
            setValue("close", close);
        }
    }
}
