package com.example.ch06startactforresult;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;



public class ControlPanelActivity extends AppCompatActivity {

    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private String account,playerName,icon,stockID;
    private int playerCash,passingDays;
    private boolean isMute,isShowChar,isShowBackGround;
    private DBHelper dbHelper;
  //  private AlertDialog.Builder builder;
    private static final int REQUEST_CODE_LOGIN = 1;
    private static final int REQUEST_CODE_CREATE_ROLE = 2;
    private Cursor cursor;

    private TextView tvDays;
    private Button btnLogIn,btnGameStart,btnCreateRole;
    private TextView tvPlayerName;
    private ImageView imgIcon;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control_panel);
        dbHelper = new DBHelper(this);
        preferences = getSharedPreferences("localSetting",MODE_PRIVATE);

        tvDays = findViewById(R.id.tvDays);
        btnLogIn = findViewById(R.id.btnLogIn);
        btnGameStart = findViewById(R.id.btnGameStart);
        btnGameStart.setOnClickListener(gameStartListener);
        btnCreateRole = findViewById(R.id.btnCreateRole);
        btnCreateRole.setOnClickListener(createRoleListener);
        tvPlayerName= findViewById(R.id.tvPlayerName);
        imgIcon = findViewById(R.id.imgIcon);
        imgIcon.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isLogIn()){
                    selectPlayer();}
                else{
                    Toast.makeText(ControlPanelActivity.this, getResources().getString(R.string.plzLogIn),Toast.LENGTH_SHORT).show();
                }
            }
        });

        //站時先設定登入中
        editor = preferences.edit();
        editor.putString("account", "111111@gmail.com");
        editor.commit();
        account = preferences.getString("account","");


    }



    private boolean isLogIn(){
        account = preferences.getString("account","");
        if (!account.equals("")){
            return true;   }
        return false;
    }

    private void loadingLocalUserData(){


        if(isLogIn()){
            account = preferences.getString(DBHelper.COLUMN_ACCOUNT,"");
            btnLogIn.setText("Log Out");
            btnLogIn.setOnClickListener(logOutListener);
            playerName = preferences.getString(DBHelper.COLUMN_PLAYER,"");
            if(playerName.equals("")){
                tvDays.setText("DAY ?");
                tvPlayerName.setText(getResources().getString(R.string.NOT_LOGIN));
                imgIcon.setImageResource(R.drawable.point);
            }
            else{
                setLocalUserData();
            }
        }
        else{
            btnLogIn.setText("Log In");
            btnLogIn.setOnClickListener(logInListener);
            tvDays.setText("DAY ?");
            tvPlayerName.setText(getResources().getString(R.string.NOT_LOGIN));
            imgIcon.setImageResource(R.drawable.point);

        }

    }

    private void setLocalUserData(){
        cursor=null;
        playerName = preferences.getString(DBHelper.COLUMN_PLAYER,"");
        cursor = dbHelper.queryPlayerData(account,playerName);
        if(cursor.getCount()>0){
            cursor.moveToFirst();
            icon = cursor.getString(2);
            playerCash = cursor.getInt(3);
            passingDays = cursor.getInt(4);
            stockID = cursor.getString(5);
            tvPlayerName.setText(playerName);
            tvDays.setText("DAY "+passingDays);

            imgIcon.setImageResource(R.drawable.icon);
        }
        /*
        cursor=null;
        cursor = dbHelper.queryNonClearPlayerData(account,0);
        if(cursor!=null){
            cursor.moveToFirst();
            String target="";
            while (!cursor.isAfterLast()){
                target = cursor.getString(1);
                if(playerName.equals(target))
                {
                    String playerName = cursor.getString(1);
                    String charName = cursor.getString(2);
                    int passingDays= cursor.getInt(4);
                    tvDays.setText("DAY "+passingDays);
                    tvPlayerName.setText(playerName);
                    imgIcon.setImageResource(R.drawable.icon);
                    return;
                }
                cursor.moveToNext();
            }
        }
*/
    }





    OnClickListener logInListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
          //  Intent intent = new Intent(ControlPanelActivity.this,LogInActivity.class);
        //    startActivityForResult(intent,REQUEST_CODE_LOGIN);

        }
    };

    OnClickListener logOutListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            editor = preferences.edit();
            editor.clear();
            editor.commit();
            loadingLocalUserData();
        }
    };


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if(requestCode==REQUEST_CODE_LOGIN){
            switch (resultCode){
                case RESULT_OK:
                    account = data.getExtras().getString("account");
                    editor = preferences.edit();
                    editor.putString("account",account);
                    editor.commit();
                    loadingLocalUserData();
                    break;
                default:
                    break;
            }
        }
        else if(requestCode==REQUEST_CODE_CREATE_ROLE){
            if(resultCode==RESULT_OK){
                Toast.makeText(ControlPanelActivity.this,
                        getResources().getString(R.string.NEW_PLAYER) +" "+
                        data.getExtras().getString(DBHelper.COLUMN_PLAYER) ,Toast.LENGTH_SHORT).show();
                editor = preferences.edit();
                editor.putString(DBHelper.COLUMN_PLAYER,data.getExtras().getString(DBHelper.COLUMN_PLAYER));
                editor.commit();
                loadingLocalUserData();
            }
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadingLocalUserData();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private void gotoStockGame(){

        Intent intent = new Intent(ControlPanelActivity.this,StockGameActivity.class);
        intent.putExtra(DBHelper.COLUMN_ACCOUNT,account);
        intent.putExtra(DBHelper.COLUMN_PLAYER,playerName);
       // intent.putExtra(DBHelper.COLUMN_ICON,icon);
      //  intent.putExtra(DBHelper.COLUMN_CASH,playerCash);
     //   intent.putExtra(DBHelper.COLUMN_DAYS,passingDays);
      //  intent.putExtra(DBHelper.COLUMN_STOCK_ID,stockID);
        startActivity(intent);
    }

    OnClickListener gameStartListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            playerName = preferences.getString(DBHelper.COLUMN_PLAYER,"");
            if(isLogIn()){
                if(!playerName.equals("")){
                    cursor.moveToFirst();
                    AlertDialog.Builder builder = new AlertDialog.Builder(ControlPanelActivity.this, R.style.MyAlertDialogTheme)
                            .setTitle(getResources().getString(R.string.GAME_START))
                            .setMessage(cursor.getString(1)+" "+"DAY " +cursor.getInt(4))
                            .setPositiveButton(getResources().getString(R.string.POSITIVE), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    gotoStockGame();
                                }
                            })
                            .setNegativeButton(getResources().getString(R.string.NEGATIVE), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            })
                            .setCancelable(false);
                    builder.show();

                }
                else{
                    Toast.makeText(
                            ControlPanelActivity.this, getResources().getString(R.string.plzChange),Toast.LENGTH_SHORT).show();
                }
            }
            else{
                Toast.makeText(
                        ControlPanelActivity.this, getResources().getString(R.string.plzLogIn),Toast.LENGTH_SHORT).show();
            }
        }
    };

    OnClickListener createRoleListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
           /*
            if(isLogIn()){
                Intent intent = new Intent(ControlPanelActivity.this,CreareRoleActivity.class);
                intent.putExtra("account",account);
                startActivityForResult(intent,REQUEST_CODE_CREATE_ROLE);
            }
            else {
                Toast.makeText(ControlPanelActivity.this,
                        getResources().getString(R.string.plzLogIn),Toast.LENGTH_SHORT).show();
            }*/
        }
    };


    private void selectPlayer(){
        cursor = null;
        cursor =dbHelper.queryNonClearPlayerData(account,0);
        final String[] oldRoles;
        if(cursor.getCount()>0){
            oldRoles = new String[cursor.getCount()];
            String playerName;
            cursor.moveToFirst();
            for(int i=0;i<oldRoles.length;i++){
                playerName = cursor.getString(1);
                oldRoles[i] = playerName;
                cursor.moveToNext();
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(ControlPanelActivity.this, R.style.MyAlertDialogTheme)
                    .setTitle("請選擇角色:")
                    .setItems(oldRoles, new DialogInterface.OnClickListener(){
                        @Override

                        //只要你在onClick處理事件內，使用which參數，就可以知道按下陣列裡的哪一個了
                        public void onClick(DialogInterface dialog, int which) {
                            // Toast.makeText(ControlPanelActivity.this, "你選的是" + oldRoles[which], Toast.LENGTH_SHORT).show();
                            String selectPlayerName = oldRoles[which];
                            editor = preferences.edit();
                            editor.putString(DBHelper.COLUMN_PLAYER,selectPlayerName);
                            editor.commit();
                            setLocalUserData();
                        }
                    });
            if(oldRoles.length>0)
                builder.show();
        }
        else{
            Toast.makeText(ControlPanelActivity.this,
                    getResources().getString(R.string.plzCreate),Toast.LENGTH_SHORT).show();
        }
    }


    public void gotohistroy(View view) {
        //Intent intent = new Intent(this,StockGameActivity.class);
        //startActivity(intent);
    }
}
